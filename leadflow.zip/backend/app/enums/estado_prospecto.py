from enum import Enum


class EstadoProspecto(str, Enum):
    NUEVO = "NUEVO"
    CONTACTADO = "CONTACTADO"
    RESPONDIO = "RESPONDIO"
    INTERESADO = "INTERESADO"
    COTIZADO = "COTIZADO"
    NEGOCIACION = "NEGOCIACION"
    CLIENTE = "CLIENTE"
    DESCARTADO = "DESCARTADO"